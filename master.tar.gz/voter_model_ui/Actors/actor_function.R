


# This function creates actor
actor<-function(position,wealth,commitment){
	
	actor<-list()
	actor$position<-position
	actor$wealth<-wealth
	actor$commitment<-commitment
	
	return(actor)
	
}




